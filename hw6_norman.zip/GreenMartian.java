package application;

public class GreenMartian extends Martian implements Teleporter {

	public GreenMartian(int id) {
		
		super(id,1);
		
	}
	
	public GreenMartian(int id, int volume) {
		super(id,volume);
	}

		
	public String speak() {
		return "Id = " + getId() +", Grobldy Grock";
	}
	
	public String teleport(String dest) {
		return "Id = " + getId()+ " teleporting to " + dest;
 	}
	
	public String toString() {
		return "Green Martian: " + " Id: " + getId() + " Volume: " + getVolume();
	}
}
