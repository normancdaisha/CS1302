package exception_examples1;

public class Account {
	private double balance;
	
	public Account(double balance) {
		if(balance < 0) {
			throw new IllegalArgumentException("Balance must be greater than 0");
		}
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "Your account balance is: " + balance;
	}
	
	public static void main(String[] args) {
		try {
			Account c = new Account(1500);
			System.out.println(c);
		}
		catch(IllegalArgumentException e){
			System.out.println("Exception Caught:");
			System.out.println(e);
		}
	}
}
