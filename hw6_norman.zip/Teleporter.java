//Worked in group with Sunny and Tej
package application;

public interface Teleporter {
	
	public String teleport(String dest);

}
