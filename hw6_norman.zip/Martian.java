//Worked in group with Sunny and Tej
package application;

public abstract class Martian implements Comparable<Martian> {
	
	private int id;
	private int volume; 
	
	public Martian(int id, int volume) {
		this.id = id;
		this.volume = volume;
	}

	public boolean equals(Object o) {
		
		if(o instanceof Martian) {
			Martian m = (Martian)o;
			return this.id == m.id;
		}
		return false;
	}
	public int getId(){
		return id;
		}
	
	public int getVolume() {
		return volume;
		}
	
	public void setVolume(int volume) {
		this.volume = volume;
		}
	
	public abstract String speak();

	public int compareTo(Martian m) {
		
		double diff = this.getId() - m.getId();
		
		if(diff < 0)
			return -1;
		else if(diff>0) 
			return 1;
		else return 0;

		
	}
	
	public String toString() {
		
		String msg = String.format("Martian id=%d vol=%d",  id, volume);
		return msg;

		
	}
}
