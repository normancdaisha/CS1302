//Worked in group with Sunny and Tej
package application;

import java.util.ArrayList;

import java.util.Collections;

import application.Martian;

public class MartianManager {
	
	protected ArrayList<Martian> martians = new ArrayList<>();
	protected ArrayList<Teleporter> teleporters = new ArrayList<>();
	
	public MartianManager() {}
	
	public boolean addMartian(Martian m) {
		
		for(Martian n : martians) {
			if(n.equals(m)) {
				return false;
			}
		}
		martians.add(m);
		
		if(m instanceof Teleporter) {
			boolean exists = false;
			for(Teleporter n: teleporters) {
				if(n.equals(m)) {
					exists = true;
				}
			}
			if(!exists) {
				teleporters.add((Teleporter) m);
			}
		}
		return true;
	}
	
	public ArrayList<Martian> battle(ArrayList<Martian> invaders){
		
		ArrayList<Martian> attackers = new ArrayList<>();
		
		for(Martian i: invaders) {
			for(Martian m: martians) {
				if(getPower(i)>getPower(m)) {
					attackers.add(martians.remove(martians.indexOf(m)));
					break;
				}
			}
		}
		return attackers;

	}
	
	private int getPower(Martian m) {
		if(m instanceof RedMartian) {
			return(m.getVolume()+((RedMartian)m).getTenacity());
		}
		else {
			return m.getVolume();
			}
	}
	
	
	public boolean contains(int id) {
		
		for(Martian m: martians) {
			if(m.getId()==id) {
				return true;}
		}	
		return false;
	}
	
	public Martian getMartianAt(int i) {
		return martians.get(i);
	}
	
	public Martian getMartianClosetTo(int id) {
    	int diff = Integer.MAX_VALUE;
    	Martian m1 = new GreenMartian(0,0);
    	
    	for(Martian m: martians) {
    		if(diff > Math.abs(id - m.getId())) {
    			diff = Math.abs(id - m.getId());
    			m1 = m;
    			}
    	}
    	return m1;
    }	

    public Martian getMartainClosetTo(Martian martian) {
    	return getMartianClosetTo(martian.getId());
    }

    public Martian getMartianWithId(int id) {
		return martians.get(id);
	}
    
    public int getNumMartians() {
		return martians.size();
	}

    public int getNumTeleporters() {
		return teleporters.size();
	}

  public ArrayList<Martian> getsortedMartians(){
	  
	  ArrayList<Martian> martians1 = martians;
	  
	  Collections.sort(martians1);
	  
	  return martians1;
 	
	}

  	public Teleporter getTeleporterAt(int i) {
		return teleporters.get(i);
	}
  	
  	public String groupSpeak() {
		String s1 = "";
		
		for(Martian m: martians) {
			s1 += (m.speak()+"\n");
		}
		return s1;
	}
	public String groupTeleport(String dest) {
		String s2 = "";
		
		for(Martian m: martians) {
			if(m instanceof GreenMartian)
				s2 += ((GreenMartian)m).teleport(dest);
		}
		return s2;
	}

	public void obliterateTeleporters() {
		martians.removeAll(teleporters);
        teleporters.clear();
	}

	public Martian removeMartian(int id){
        
		if(id<0 || id>= martians.size()) {
			return null;
		}
		
		Martian removMartain = martians.get(id);
		martians.remove(id);
		return removMartain;
		
    }

	public String toString() {
		String s3 = "Martians: \n";
		for(Martian n : martians) {
			
			s3 += (n.toString() + "\n");
			
		}
		s3 += "Teleporters: \n";
		for(Teleporter n : teleporters) {
			
			s3 += n.toString();
			
		}
		return s3;
		
	}


}
