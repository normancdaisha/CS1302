//Worked in group with Sunny and Tej
package application;
import java.util.ArrayList;

import application.Martian;

public class MartianManagerTest {

	public static void main(String[] args) {

		
		testAddMartian();
		testBattle();
		testContains();
		testGetMartianAt();
		testGetMartianClosestTo();
		testGetMartianWithId();
		testGetNumMartians();
		testGetNumTeleporters();
		testGetTeleporterAt();
		testGroupSpeak();
		testGroupTeleport();
		testObliterateTeleporters();
		testRemoveMartian();
	    testToString();
	    testGetSortedMartians();
		
	}
	
	
	
	public static void testAddMartian() {
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		System.out.print("\ntestAddMartian\nExpect: 4\nResult: " + m.getNumMartians() + "\n");
		
	}
	
	public static void testBattle() {
		
		MartianManager m = new MartianManager();
		ArrayList<Martian> Invaders = new ArrayList<>();
		Invaders.add(new RedMartian(1,8, 1));
		Invaders.add(new GreenMartian(2,5));
		Invaders.add(new RedMartian(3,7, 1));
		Invaders.add(new GreenMartian(4,5));
		m.addMartian(new GreenMartian(1, 3));
		m.addMartian(new RedMartian(2, 3, 20));
		m.addMartian(new GreenMartian(3, 5));
		m.addMartian(new GreenMartian(4, 20));
		System.out.print("\ntestBattle\nExpect: GM(1,3), GM(3,5)\nResult: " + m.battle(Invaders) + "\n-------------\nExpect: RM(2,3,20), GM(4,20)\nResult: " + m.martians + "\n");
		
	}
	
	public static void testContains() {
		
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 3));
		m.addMartian(new RedMartian(2, 3, 20));
		m.addMartian(new GreenMartian(3, 5));
		m.addMartian(new GreenMartian(4, 20));
		System.out.print("\ntestContains\nExpect: true false\nResult: " + m.contains(1) + " " + m.contains(5) + "\n");
		
	}
	
	public static void testGetMartianAt() {
		
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 3));
		System.out.print("\ntestGetMartianAt\nExpect: 1\nResult: " + m.getMartianAt(0).getId() + "\n");
		
	}
	
	public static void testGetMartianClosestTo() {
		
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		m.addMartian(new RedMartian(10, 10, 5));
		System.out.print("\ntestGetMartianClosestTo\nExpect: Id 4 (int)\nResult: " + m.getMartianClosetTo(5).getId() + "\nExpect: Id 10 (Martian)\nResult: " + m.getMartainClosetTo(new GreenMartian(8,10)) + "\n");
		
	}
	
	public static void testGetMartianWithId() {
		
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		m.addMartian(new RedMartian(10, 10, 5));
		System.out.print("\ntestGetMartianWithId\nExpect 10\nResult: " + m.getMartianWithId(4).getId() + "\n");
		
	}
	
	public static void testGetNumMartians() {
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		System.out.print("\ntestGetNumMartians\nExpect: 4\nResult: " + m.getNumMartians() + "\n");
		
	}
	
	public static void testGetNumTeleporters() {
		MartianManager m = new MartianManager();
		m.addMartian(new GreenMartian(1, 10));
		m.addMartian(new GreenMartian(2, 10));
		m.addMartian(new RedMartian(3, 10, 5));
		m.addMartian(new RedMartian(4, 10, 5));
		m.addMartian(new GreenMartian(5, 10));
		m.addMartian(new GreenMartian(6, 10));
		m.addMartian(new RedMartian(7, 10, 5));
		m.addMartian(new RedMartian(8, 10, 5));
		System.out.print("\ntestGetNumTeleporters\nExpect: 4\nResult: " + m.getNumTeleporters() + "\n");
		
	}
	
	

public static void testGetTeleporterAt() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(1, 10));
	m.addMartian(new GreenMartian(2, 10));
	m.addMartian(new RedMartian(3, 10, 5));
	m.addMartian(new RedMartian(4, 10, 5));
	m.addMartian(new GreenMartian(5, 9));
	System.out.print("\ntestGetTeleporterAt\nExpect: GM(5, 9)\nResult: " + m.getTeleporterAt(2) + "\n");
	
}

public static void testGroupSpeak() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(1, 10));
	m.addMartian(new GreenMartian(2, 10));
	m.addMartian(new RedMartian(3, 10, 5));
	m.addMartian(new RedMartian(4, 10, 5));
	m.addMartian(new GreenMartian(5, 9));
	System.out.print("\ntestGroupSpeak\n" + m.groupSpeak() + "\n");
	
}

public static void testGroupTeleport() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(1, 10));
	m.addMartian(new GreenMartian(2, 10));
	m.addMartian(new RedMartian(3, 10, 5));
	m.addMartian(new RedMartian(4, 10, 5));
	m.addMartian(new GreenMartian(5, 9));
	System.out.print("\ntestGroupTeleport\n" + m.groupTeleport("else where ") + "\n");
	
}

public static void testObliterateTeleporters() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(1, 10));
	m.addMartian(new GreenMartian(2, 10));
	m.addMartian(new RedMartian(3, 10, 5));
	m.addMartian(new RedMartian(4, 10, 5));
	m.addMartian(new GreenMartian(5, 9));
	System.out.print("\ntestObliterateTeleporters\nBefore\nNumMartians: " + m.getNumMartians() + "\nNumTeleporters: " + m.getNumTeleporters());
	m.obliterateTeleporters();
	System.out.print("\nAfter Obliterate\nNumMartians: " + m.getNumMartians() + "\nNumTeleporters: " + m.getNumTeleporters() + "\n");
	
}

public static void testRemoveMartian() {
		
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(1, 10));
	m.addMartian(new GreenMartian(2, 10));
	m.addMartian(new RedMartian(3, 10, 5));
	m.addMartian(new RedMartian(4, 10, 5));
	m.addMartian(new GreenMartian(5, 10));
	m.addMartian(new GreenMartian(6, 10));
	m.addMartian(new RedMartian(7, 10, 5));
	m.addMartian(new RedMartian(8, 10, 5));
	System.out.print("\ntestRemoveMartian\nBefore: " + m.getNumMartians() + "\nRemoveing RM and GM with ID 4 & 5\nResult: ");
	m.removeMartian(4);
	m.removeMartian(5);
	System.out.print(m.getNumMartians() + "\n");
	
}

public static void testToString() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(2, 9));
	m.addMartian(new GreenMartian(5, 9));
	m.addMartian(new RedMartian(1,9, 4));
	m.addMartian(new RedMartian(3, 10, 6));
	m.addMartian(new GreenMartian(5, 10));
	m.addMartian(new GreenMartian(6, 10));
	m.addMartian(new RedMartian(7, 10, 5));
	m.addMartian(new RedMartian(8, 10, 5));
	System.out.print("\ntestToString\n" + m.toString());
	
}
public static void testGetSortedMartians() {
	
	MartianManager m = new MartianManager();
	m.addMartian(new GreenMartian(2, 9));
	m.addMartian(new GreenMartian(5, 9));
	m.addMartian(new RedMartian(1, 9, 4));
	m.addMartian(new RedMartian(3, 10, 6));
	System.out.println("\n\ntestGetSortedMartians\nOriginal: " + m.martians + "\nSorted: " + m.getsortedMartians() + "\n");

}
	


}
