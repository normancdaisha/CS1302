//Worked in group with Sunny and Tej
package application;

import application.Martian;

public class RedMartian extends Martian {
	
	private int tenacity;
	
	public RedMartian(int id, int tenacity) {
		super(id,1);
		this.tenacity = tenacity;
	}
	
	public RedMartian(int id, int volume, int tenacity) {
		
		super(id,volume);
		this.tenacity = tenacity;
		
	}
	
	public int getTenacity() {
		
		return tenacity;
		
	}
	
	public String speak() {
		return "Id =" + getId() + " Rubldy Rock";
	}
	
	public String toString() {
		return "Red Martian - Id = " + getId() +", Volume = "
				+ getVolume() + ",tenacity = " + getTenacity();
	}

}
