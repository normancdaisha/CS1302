package application;
	
import application.ShapeGenerator.CreateShapeEventHandler;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class Main6 extends Application {
	protected CheckBox chkDineIn, chkTakeOut, chkDelivery;
	protected Label lblSpecialInstructions;
	protected TextArea txaMessage;
	protected Button btnCreateOrder;
	protected ListView<String> lvwInterests = new ListView<>();
	protected Label lbl;
	protected TextField txfName;
	protected Label tip;
	protected ComboBox<String> cmbTip;
	protected Label food;
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane root = buildGui();
			Scene scene = new Scene(root,400,360);
			primaryStage.setTitle("Dino's Diner");
			// Code to display the Gui
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private Pane buildGui() {
		GridPane root = new GridPane();
		
		Pane p = buildDiningEntry();
		root.add(p,0, 0);
		

		p = buildSelectFoodEntry();
		root.add(p, 1, 0);
		
		p = buildTipEntry();
		root.add(p, 0, 1);
		
		
		//root.add(btnCreateOrder, 0, 2);
		//root.add(txaMessage, 0, 3);
		
		//txaMessage = new TextArea();
		//txaMessage.setPrefHeight(100);
		//txaMessage.setPrefWidth(300);
		//btnCreateOrder = new Button("Create Order");
		//lbl = new Label("Special Instructions");
		//txfName = new TextField();
		//tip = new Label ("Tip");
		// Add other controls to GridPane
		//root.add(btnCreateOrder, 0, 2);
		//root.add(txaMessage, 0, 4);
		//root.add(lbl, 0, 1);
		//root.add(txfName, 0, 2);
		//root.add(tip, 1, 3);
		return root;
	}
  private Pane buildDiningEntry() {
	lbl = new Label("Special Instructions");
    txfName = new TextField();
	chkDineIn = new CheckBox("Dine In");
	chkTakeOut = new CheckBox("Take Out");
	chkDelivery = new CheckBox("Delivery");
	VBox vBoxDining = new VBox();
	vBoxDining.getStyleClass().add("h_or_v_box");
	vBoxDining.getChildren().addAll(chkDineIn, chkTakeOut, chkDelivery, lbl, txfName);
	

	return vBoxDining;
	
	}
  
  private Pane buildSelectFoodEntry() {
	    food = new Label("Select food item");
		lvwInterests.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		lvwInterests.getItems().addAll("Burger", "Fries", "Hummus", "Soda");
		lvwInterests.setPrefHeight(150);
		lvwInterests.setPrefWidth(120);
		HBox selectFood = new HBox();
	    selectFood.setSpacing(10);
		//selectFood.getChildren().add(new Label("Select food items"));
		selectFood.getChildren().addAll(food,lvwInterests);
		return selectFood;
		
  }
  
  private Pane buildTipEntry() {
	    txaMessage = new TextArea();
		txaMessage.setPrefHeight(100);
		txaMessage.setPrefWidth(300);
		
		btnCreateOrder = new Button("Create Order");
		tip = new Label ("Tip");
		
		VBox Tip = new VBox();
		Tip.getChildren();
		cmbTip = new ComboBox<>();
		cmbTip.getItems().addAll("5%", "10%", "15%", "20%");
		cmbTip.setValue("20%");

		Tip.getChildren().addAll(btnCreateOrder, tip, cmbTip,txaMessage);

		return Tip;
		
	}
  
  CreateOrderEventHandler btnCreateOrderEventHandler = new CreateOrderEventHandler();
  btnCreateOrder.setOnAction(btnCreateOrderEventHandler);
}

private class CreateOrderEventHandler implements EventHandler<ActionEvent> {
	@Override
	public void handle(ActionEvent event) {
		
	}
  
	public static void main(String[] args) {
		launch(args);
	  }
	}
